java -classpath target/classes -Djava.rmi.server.hostname=127.0.0.1 rmi.server.HelloServer
