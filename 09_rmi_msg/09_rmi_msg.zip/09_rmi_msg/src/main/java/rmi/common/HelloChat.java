package rmi.common;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface HelloChat extends Remote {
    void message(String name, String message) throws RemoteException;
}
