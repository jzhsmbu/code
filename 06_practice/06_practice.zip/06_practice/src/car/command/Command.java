package car.command;

public interface Command {
    boolean execute();
}
