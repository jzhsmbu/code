package net;

public enum CommandCode {
    UP, DOWN, LEFT, RIGHT, CHANGECOLOR, SETNAME
}