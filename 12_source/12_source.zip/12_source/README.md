1. start Hello (webservice.server)
2. mvn install (this command generate SOAP client)