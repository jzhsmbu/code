package client;

import car.webservice.Server;
import car.webservice.ServerService;

import java.net.URL;
public class Client {
    public static void main(String[] args) throws Exception {
        String url = "http://127.0.0.1:8080/CarServer?wsdl";
        ServerService service = new ServerService(new URL(url));
        Server serverPort = service.getServerPort();
        int carIndex = serverPort.createCar();
        System.out.println("carIndex = " + carIndex);
    }
}