1. start Hello (server)
2. mvn clean install (this command generate SOAP client)