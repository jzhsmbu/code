package tcp;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class SerializeTCPServer {
    public static void main(String args[]) {
        try {
            int serverPort = 8088; // the server port
            ServerSocket listenSocket = new ServerSocket(serverPort); // new server port generated
            System.out.println("SerializeServer listen port: " + serverPort);
            while (true) {
                Socket clientSocket = listenSocket.accept(); // listen for new connection
                ObjectOutputStream ous = new ObjectOutputStream(clientSocket.getOutputStream());
                ObjectInputStream ois = new ObjectInputStream(clientSocket.getInputStream());
                Object data = ois.readObject();
                System.out.println("Received data: " + data);
            }
        } catch (IOException e) {
            System.out.println("Listen socket:" + e.getMessage());
        } catch (ClassNotFoundException e){
            e.printStackTrace();
        }
    }
}