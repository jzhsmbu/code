package tcp;

import java.io.Serializable;
import java.util.Arrays;

public class Message implements Serializable {
    public int priority;
    public String message;
    public Integer[] data = new Integer[10];
    public Message(int p, String msg) {
        this.priority = p;
        this.message = msg;
        Arrays.fill(data, 20);
    }
        @Override
        public String toString() {
            return "class Message: priority=" + priority + " message=" + message + " arrays=" + Arrays.asList(data);
        }
}