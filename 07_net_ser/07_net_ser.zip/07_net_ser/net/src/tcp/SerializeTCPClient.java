package tcp;

import java.io.IOException;
import java.io.EOFException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class SerializeTCPClient {
    public static void main(String args[]) {
        // arguments supply message and hostname
        int serverPort = 8088;
        String serverHost = "localhost";//args[1];
        String message = "Hello world";//args[6];
        System.out.print("Connecting to "+serverHost+":"+serverPort+"...");
        try (Socket s = new Socket(serverHost, serverPort)) {
            System.out.println("Connected!");
            ObjectInputStream in = new ObjectInputStream(s.getInputStream());
            ObjectOutputStream out = new ObjectOutputStream(s.getOutputStream());
            Message msg = new Message(9, "HELP!!!");
            out.writeObject(msg);
            System.out.println("Data sent: " + msg);
        } catch (
                UnknownHostException e) {
            System.out.println("Socket:" + e.getMessage()); // host cannot be resolved
        } catch (
                EOFException e) {
            System.out.println("EOF:" + e.getMessage()); // end of stream reached
        } catch (
                IOException e) {
            System.out.println("Readline:" + e.getMessage()); // error in reading the stream
        }
    }
}